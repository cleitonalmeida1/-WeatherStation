#include "mbed.h"
#include "TripledData.h"

DigitalOut myled(LED1);

int main() {
   

    return 0;
}
